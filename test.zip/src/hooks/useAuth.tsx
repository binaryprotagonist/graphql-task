const useAuth = () => {
    return true;
  };

  export default useAuth;
