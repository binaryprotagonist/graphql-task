import { useQuery, gql } from "@apollo/client";
import { useState, useEffect } from 'react';
import Pagination from 'components/Pagination/Pagination'

interface LaunchesPast {
  id: string,
  mission_name: string
}

interface Filter {
  mission_name: string,
  rocket_name: string
}

function LaunchesPage() {

  const [filterField,setFilterField] = useState<Filter>({
     mission_name: '',
     rocket_name: ''
  })

  const [ pagination] = useState({
    limit: 10,
    offset: 0,
  })

  const [skip,setSkip] = useState<boolean>(false)
  const [dataStore, setDataStore] = useState<any>({});

  const handleFilterField = (e: React.ChangeEvent<HTMLInputElement>) => {
     const name  = e.target.name;
     const value = e.target.value;
     setFilterField({...filterField,[name]:value});
  }

  const submitFilterFiled = (e: React.SyntheticEvent) => {
       e.preventDefault()
       setSkip(false)
  }

  const getLaunches = () => {
    return gql`
    {
      launchesPast(limit: ${pagination.limit}, offset: ${pagination.offset}, find: {mission_name: "${filterField.mission_name}", rocket_name:
      "${filterField.rocket_name}" }){
        id
        mission_name
        launch_date_local
        launch_site {
          site_name_long
        }
        launch_success
        links {
          wikipedia
        }
        rocket {
          rocket_name
          first_stage {
            cores {
              flight
              core {
                reuse_count
                status
              }
            }
          }
          second_stage {
            payloads {
              payload_type
              payload_mass_kg
            }
          }
          rocket_type
        }
      }
      ships {
        name
        home_port
        image
      }
    }
  `;
}

const { data, loading, error } = useQuery(getLaunches(), { skip });

console.log('render', dataStore)

useEffect(() => {
  console.log(data)
  if (!loading && !!data) {
    setSkip(true)
    setDataStore(data);
  }
}, [data, loading])

if (loading) return "Loading...";
if (error) return <p>{error?.message}</p>

  return (
    <div className="LaunchesPage">
        <h1>Launches Past</h1>
        <div className="filter">
           <form onSubmit={submitFilterFiled}>
                <input name="mission_name" value={filterField.mission_name} onChange={handleFilterField} placeholder="Mission name" />
                <input name="rocket_name" value={filterField.rocket_name} onChange={handleFilterField} placeholder="Rocket name" />
                <button type="submit">Search</button>
            </form>
        </div>
        <div className="item">
          {
            dataStore ? (
              dataStore?.launchesPast?.map((launch: LaunchesPast) => (
                <li key={launch.id}>{launch.mission_name}</li>
              ))
            ): <div>Record not found</div>
          }
        </div>
        <Pagination></Pagination>
    </div>
  )
}

export default LaunchesPage