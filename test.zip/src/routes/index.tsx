import LaunchesPage from 'pages/LaunchesPage/Index';
import { Route } from 'models/comman'

export const routes: Route[] = [
  {
    path: '/',
    element: LaunchesPage,
    isPrivate: false,
  },
];
