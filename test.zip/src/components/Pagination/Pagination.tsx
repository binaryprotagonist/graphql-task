import { Link } from 'react-router-dom';
import './Pagination.css'


const  Pagination = () => {

  return (
        <div className="pagination">
            <Link to="/">&laquo;</Link>
            <Link to="/">1</Link>
            <Link className="active" to="/">2</Link>
            <Link to="/">3</Link>
            <Link to="/">4</Link>
            <Link to="/">5</Link>
            <Link to="/">6</Link>
            <Link to="/">&raquo;</Link>
        </div>
  )
}

export default Pagination