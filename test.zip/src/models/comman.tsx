export interface Route {
    path: string,
    element: React.FunctionComponent,
    isPrivate: Boolean
}